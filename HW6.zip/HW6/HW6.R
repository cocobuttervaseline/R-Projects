#Task 1 
#Create a tibble from the data frame mtcars, and name the tibble "mtcars_tibble". 

library(dplyr)
mtcars
mtcars_tibble <- tibble(mtcars)
print(mtcars_tibble)



#Task 2 
#Following task 1, now use a pipeliine to first filter "mydata_tibble" to show only 
#vehcles with more than 4 cylinders (i.e., cyl>4), and then sort the resulting table 
#based on "hp" in an ascending order 

mydata_tibble <- mtcars_tibble%>%
  filter(cyl>4)%>%
  arrange(hp)
print(mydata_tibble)



#Task 3
#Following task 1, please use pipeline to first extract only the "mpg", "disp", 
#"hp", "cyl" columns and then create a new column in the resulting table to show the 
#horse power cylinder (horse power per cylinder is calculated as hp/cyl,) name this new
#column "hppercyl"). Your result should look like the following: 

mtcars_tibble %>%
  mutate(hppercyl = hp/cyl) %>%
  select(mpg, disp, hp, cyl, hppercyl)

































