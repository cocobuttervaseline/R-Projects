
# Task 1 

model <- lm(Price~KM+HP+CC+Weight+Guarantee_Period, data = ToyotaCorollaPrice)
summary(model)

# Please write down the estimated model with the estimated coefficients inserted, 
# such as "amountspent = -4.428e+01 + (-1.987e+01)*children + 2.041e-03 * income +
# 4.770e+00*catelog" mentioned in the lecture 

Price = -2.987e+04 -4.958e - 02*KM + 2.134e+01*HP -1.022e-01*CC 
#3.883e+01*Weight + 9.124e+01*Guarantee_Period



# Task 2 

# Answer: Estimated coefficient for KM is -4.958e-02 (-4.958*10^-2 = -0.04958)
# For one additional KM, the car price decreases by 0.04958 dollars on average 



# Task 3 

# Answer: The coefficient estimate wwith the highest P-value is -1.022e-01 for
# variable "CC". The P-value for "CC" is 0.471 and the coefficient estimated value
# is essentially 0, or no difference from 0, which makes it insignificant. This 
# immplies that the vehicle's "CC" (or displacement) has nothing to do with the 
# vehicle's resale value. All other coefficient estimates (except "CC") have
# P-values smaller than 0.01 and are statistically significant. 



# Task 4 

predicted.price <- predict(model, data = ToyotaCorollaPrice)

predicted.price[2]
ToyotaCorollaPrice$Price[2]




# Task 5 

# Scripts

model2 <- lm(Price~KM+HP+CC+Weight+Guarantee_Period, data = ToyotaCorollaPrice,
subset = Fuel_Type == "Petrol")
summary(model2)



model3 <- lm(Price~KM+HP+CC+Weight+Guarantee_Period, data = ToyotaCorollaPrice, 
subset = Fuel_Type == "Diesel")
summary(model3)





















