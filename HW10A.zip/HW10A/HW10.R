#Task 2 

mydata <- DairyFarm
hist(DairyFarm$milk, breaks = 50)

install.packages("cars")
plot(milk~cows, data = DairyFarm)
plot(logmilk~logcows, data = DairyFarm)

#The difference between the two plots would be the fact that plot - cows has more paints skewered
#together while the logmilk~logcows is spread a little more evenly with heavier emphasis above
#3.0 logcows 12logmilk, overall both plots have sudden changes in the positions. 



#Task 3 

mydata <- DairyFarm
model3 <- lm(logmilk~logcows + logland + loglabor + logfeed + factor(year) + factor(farm),
             data = mydata)

summary(model3)


#logcost = ...0.6379665 * logcows 
#1% difference in number of cows and causes 0.6379665% change in milk 
#must look at the coefficient at logcow year 94 and factor farm 15 
#and also use baseline of year 93 to find the answer 



#Task 4 

model3 <- lm(logmilk ~ logcows + logland + loglabor + logfeed + factor(farm) + factor(year), 
             data = mydata)

summary(model3)
































