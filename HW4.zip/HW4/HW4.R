
#TASK 1 

# x vector with given number
x = c(12, 32, 33, 44)

#The first component is 
head(x, 1)

#The final component 
tail(x, 1)



#TASK 2 

y = x**2 
y 




#TASK 3 

x = c("hayward", "fremont", "union city", "san jose", "castro valley")
y = nchar(x)
y





#TASK 4 

# There are two lists in lst1
lst1 = list(c(1, 2, 3), "dog")
# There are three lists in list 2
lst2 = list(TRUE, NULL, c('good', 'bad'))


# Printing list1 
print(lst2)
# The list was printed for the second time 
print(lst2)
# Concate the list 
lst3 = list(lst1, lst2)
# Print out list3 
print(lst3)

# In lst3, there are two main lists, index one has lst1, and index two has lst2 
# We use index 1 show list1 to gain access to lst3 
lst3[1]

# When we use double square brackets, we get a nested list with index 1 
lst3[[1]]







