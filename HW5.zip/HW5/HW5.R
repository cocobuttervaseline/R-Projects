# Task 1 
# Please use a for loop to calculate the sum over 2, 4, 6, 8, ..., 100. 
x <- 0 

# Hint: seq(2, 100, 2) will generate a vector from 2 to 100, with a step of 2. 
for (i in seq(2, 100, 2))
{ x <- x + i
  print(x)}


# Task 2
# Define a variable x = 1, use a while loop to keep tripling itself until 
# the result is larger than 10,000. At the last, output the number of iterations
# used. 
x <- 1 

# Hint: initialize aa variable (i.e., cnt = 0) to record of the number of 
# iterations used. 
cnt <- 0 
while (TRUE) 
{x <- x*3 
  print(x)
  cnt <- cnt + 1
  if(x > 10000)
  break}



# Task 4
# Given the following data frame, please use logical slicing to get a sub data frame 
# where the product is "Toaster". 

df = data.frame (
  CustomerId = c(1:7), 
  Product = c(rep("Toaster", 3),
              rep("Radio", 4))
)
df[1:3, 1:2]





















