install.packages("party")
library(party)

# 1. import the dataset and call it "mydata". Then check the 
# structure of the data

mydata <- admit


# 2. convert the data type of the admit and the rank column from int to 
# factors 

mydata$admit <- as.factor(mydata$admit)
mydata$rank <- as.factor(mydata$rank)


# 3. randomly select 80% of the dataset as training set and the rest as
# the testing set 

train.id <- sample(1:nrow(mydata), size = 0.8*nrow(mydata))
trainset <- mydata[train.id,]
testset <- mydata[-train.id,]



# 4. train a decision tree model, using admit as the category, and gre, gpa, and rank 
# as predictors. Then plot the tree

decisiontree <- ctree(admit~., data = trainset)
plot(decisiontree)




# 5. Please answer the question: if a candidate has a GPA of 3.7, and 
# rank of 4, does this candidate have a higher chance to be admitted or 
# to be rejected? Please note that when you only have two categories, the 
# darker proportion stands for the proportion for 1 in the end node of the tree plot

# Answer: According to the tree plot, a student with a GPA of 3.7 and a rank of 4
# has a very high chance to be rejected. Data from Node 8 and 9 only represents 
# students ranking 1 and 2 respectively, not 3 or 4. 



# 6. Please calculate the accuracy of your decision tree model

predicted.admission <- predict(decisiontree, testset)
actual.admission <- testset$admit
tab <- table(predicted.admission, actual.admission)
accuracy = (48 + 8)/sum(tab)

> accuracy
[1] 0.7


















