#load data set "admit" and select column "GRE" & "GPA"

mydata <- admit[,c(2,3)]


# standardize data set 
mydata.standardized <- scale(mydata)



# With two clusters - 4th applicant is in cluster "2" as shown in data below

# hierarchical clustering 

pairwisedistance = dist(mydata.standardized)
hc <- hclust(pairwisedistance)
plot(hc)


# complete link method 

hc.c <- hclust(pairwisedistance, method = "complete")
plot(hc.c)


# cut tree 

cluster <- cutree(hc.c, 2)










